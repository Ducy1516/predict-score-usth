export default function Home() {
  return <h1>Dự đoán điểm chuẩn USTH 2025 🎯</h1>;
}