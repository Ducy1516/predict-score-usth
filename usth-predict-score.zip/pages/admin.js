export default function Admin() {
  return <h1>Trang quản lý kết quả 🎯</h1>;
}