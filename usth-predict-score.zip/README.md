# DỰ ĐOÁN ĐIỂM CHUẨN USTH 2025 🎯

Minigame dự đoán điểm chuẩn các ngành USTH theo hình thức Over/Under. Dành cho sinh viên, học sinh USTH mùa tuyển sinh 2025.
